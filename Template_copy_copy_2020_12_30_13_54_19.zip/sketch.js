
var monkey , monkey_running
var banana ,bananaImage,bananaGroup
var obstacle, obstacleImage, obstacleGroup
var FoodGroup
var ground
var score

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  //obstaceImage = loadImage("obstacle.png");
  //bananaImage = loadImage("banana.png")
  stoneImage = loadImage("obstacle.png")
}



function setup() {
  monkey = createSprite(80,315,20,20)
  monkey.addAnimation("moving",monkey_running)
  monkey.scale = 0.1
  
  ground = createSprite(400,350,900,10)
  ground.velocityX = -4
  ground.x = ground.width/2
  console.log(ground.y)
 
  bananaGroup = createGroup();
  stoneGroup = createGroup();

  
}


function draw() {

  background(255)
  if (ground.x < 0){
      ground.x = ground.width/2;
    }

  
  if(keyDown("space")&& monkey.y >= 305) {
        monkey.velocityY = -12;
        //jumpSound.play();
    }
  
  monkey.velocityY = monkey.velocityY + 0.7
  
  monkey.collide(ground)

  spawnBanana()
  spawnStone() 
  
 drawSprites() 
}

function spawnBanana() {
  
  if (frameCount % 80 === 0) {
    var banana = createSprite(500,200,100,100);
    banana.y = Math.round(random(210,260));
    banana.addImage(bananaImage);
    banana.scale = 0.1;
    banana.velocityX = -3;
    banana.lifetime = 200; 
    bananaGroup.add(banana);
    console.log(200)
  }
}
function spawnStone() {
  
  if (frameCount % 300 === 0) {
    var stone = createSprite(600,330,100,100);
    //st.y = Math.round(random(311,350));
    stone.addImage(stoneImage);
    stone.scale = 0.1;
    stone.velocityX = -3;
    stone.lifetime = 200; 
    stoneGroup.add(stone);
  }
}









